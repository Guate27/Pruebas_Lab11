package com.uvg.mypokedex.data.model

import androidx.compose.ui.graphics.Color

val normalColor = Color(0xFFA8A77A)//Tipo Normal
val fireColor = Color(0xFFEE8130)// Tipo Fuego
val waterColor = Color(0xFF6390F0)//Tipo Agua
val electricColor = Color(0xFFF7D02C)//Tipo Eléctrico
val grassColor = Color(0xFF7AC74C)//Tipo Planta
val iceColor = Color(0xFF96D9D6)//Tipo Hielo
val fightingColor = Color(0xFFC22E28)//Tipo Lucha
val poisonColor = Color(0xFFA33EA1)//Tipo Veneno
val groundColor = Color(0xFFE2BF65)//Tipo Tierra
val flyingColor = Color(0xFFA98FF3)//Tipo Volador
val psychicColor = Color(0xFFF95587)//Tipo Psiquico
val bugColor = Color(0xFFA6B91A)//Tipo Bicho
val rockColor = Color(0xFFB6A136)//Tipo Roca
val ghostColor = Color(0xFF735797)//Tipo Fantasma
val dragonColor = Color(0xFF6F35FC)//Tipo Dragon
val darkColor = Color(0xFF705746)//Tipo Siniestro
val steelColor = Color(0xFFB7B7CE)//Tipo Acero
val fairyColor = Color(0xFFD685AD)//Tipo Hada
// Se agradece formalmente a Denil Parada por su paciencia y guía para dicho código
