package com.uvg.mypokedex.data.model

enum class PokeType {
    BUG, DRAGON, FAIRY, FIRE, GHOST, GROUND, NORMAL, PSYCHIC, STEEL, DARK, ELECTRIC, FIGHTING, FLYING, GRASS, ICE, POISON, ROCK, WATER
}
// Se agradece formalmente a Denil Parada por su paciencia y guía para dicho código
